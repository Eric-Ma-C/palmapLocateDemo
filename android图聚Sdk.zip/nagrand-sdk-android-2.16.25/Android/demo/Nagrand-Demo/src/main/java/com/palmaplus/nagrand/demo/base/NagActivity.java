package com.palmaplus.nagrand.demo.base;

import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;



/**
 * Created by Overu on 2015/8/7.
 */
@Retention(RUNTIME)
public @interface NagActivity {
}
