package com.palmaplus.nagrand.demo.widget;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by zhang on 2015/10/21.
 */
public class MyProgressDialog extends ProgressDialog {

    public MyProgressDialog(Context context) {
        super(context);
    }

    public MyProgressDialog(Context context, int theme) {
        super(context, theme);
    }

}
