package com.palmaplus.nagrand.quickstart;

/**
 * Created by zhang on 2015/4/29.
 */
public class Constant {
  public static final String LUA_NAME = "Nagrand/lua"; // lua地址
  public static String APP_KEY = "8bb3e97eaa754fcdbfa9537901a0a800"; // appKey，可以从图聚的开发者平台上获取

}
