package com.palmap.demo.palmaprtmap;

/**
 * Created by eric3 on 2016/9/29.
 */
public class Constant {
//  public static final String APP_KEY = "19e7db5672824721a9e47ac84a8aa222";//图聚办公室的
//  public static final long MAP_ID = 6;//图聚办公室的


//  public static final String APP_KEY = "a4fdfd115c83494ba8f99146fd179a52";//莱茵广场的
//  public static final long MAP_ID = 1379;//莱茵广场的

  public static final String APP_KEY = "944dd695d4e74ccb8c7d2499a800b882";//莱茵广场的
public static final long MAP_ID = 1315;//莱茵广场的

  public static final String RMAP_NAME = "rtmapwh/mdata";

  public static final boolean isDebug = true;
}
