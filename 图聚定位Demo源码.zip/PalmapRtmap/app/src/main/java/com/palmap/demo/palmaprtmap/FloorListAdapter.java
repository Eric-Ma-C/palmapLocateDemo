package com.palmap.demo.palmaprtmap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by eric on 2016/9/29.
 */
public class FloorListAdapter extends BaseAdapter {

  private MainActivity mContext;
  private List<String> mFloorList;

  public FloorListAdapter(Context context, List<String> floorList){
    this.mContext = (MainActivity)context;
    this.mFloorList = floorList;
  }

  @Override
  public int getCount() {
    if (mFloorList == null){
      return 0;
    }
    return mFloorList.size();
  }

  @Override
  public String getItem(int position) {
    return mFloorList.get(position);
  }

  @Override
  public long getItemId(int position) {
    return position;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    ViewHolder viewHolder;
    if (convertView == null){
      viewHolder = new ViewHolder();
      convertView = LayoutInflater.from(mContext).inflate(R.layout.item_floor_list, null);
      viewHolder.floorName = (TextView) convertView.findViewById(R.id.map_floor_list_item);
      convertView.setTag(viewHolder);
    } else {
      viewHolder = (ViewHolder) convertView.getTag();
    }

    // 设置控件内容
    viewHolder.floorName.setText(mFloorList.get(position));

    return convertView;
  }

  class ViewHolder{
    TextView floorName;
  }

}

